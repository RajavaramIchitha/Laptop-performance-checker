from flask import Flask, render_template, request, redirect, url_for, session
import bcrypt
import psutil

app = Flask(__name__)
app.secret_key = "your_secret_key"  # Replace with a strong secret key

# Temporary user storage (use a database in production)
users = {}

@app.route('/')
def index():
    if 'logged_in' not in session:
        return redirect(url_for('login'))

    # Fetch real-time performance metrics
    performance = {
        "cpu": psutil.cpu_percent(interval=1),  # CPU usage in percentage
        "ram": psutil.virtual_memory().percent  # RAM usage in percentage
    }

    # Fetch battery information (if available)
    battery = psutil.sensors_battery()
    if battery:
        if battery.secsleft == psutil.POWER_TIME_UNLIMITED or battery.secsleft < 0:
            time_left = "Calculating..."
        else:
            time_left = round(battery.secsleft / 60)  # Convert seconds to minutes and round off

        battery_info = {
            "percent": battery.percent,
            "time_left": time_left
        }
    else:
        battery_info = {
            "percent": "N/A",
            "time_left": "N/A"
        }

    # Placeholder for temperature and disk health (enhance later if needed)
    temperature = {"temperature": "N/A"}  # psutil doesn't support temperature on all platforms
    disk_health = {"status": "Healthy"}  # Replace with actual disk health check logic

    return render_template('index.html',
                           performance=performance,
                           battery=battery_info,
                           temperature=temperature,
                           disk_health=disk_health)


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        if username in users and bcrypt.checkpw(password.encode('utf-8'), users[username]):
            session['logged_in'] = True
            return redirect(url_for('index'))
        else:
            error = "Invalid username or password"
            return render_template('login.html', error=error)

    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('logged_in', None)
    return redirect(url_for('login'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')

        if username in users:
            error = "Username already exists. Please choose a different one."
            return render_template('register.html', error=error)

        if password != confirm_password:
            error = "Passwords do not match. Please try again."
            return render_template('register.html', error=error)

        # Hash the password before storing it
        hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())
        users[username] = hashed_password
        return redirect(url_for('login'))

    return render_template('register.html')

if __name__ == "__main__":
    app.run(debug=True)
