from pySMART.smartctl import Smartctl

# Create an instance of Smartctl
smartctl = Smartctl()

# Test the --scan-open functionality
try:
    disks = smartctl.scan()
    print("Detected disks:")
    for disk in disks:
        print(disk)
except Exception as e:
    print(f"Error: {e}")

