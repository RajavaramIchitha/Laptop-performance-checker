import subprocess
import os
import logging

logger = logging.getLogger(__name__)

def run_smartctl_command(args):
    """
    Run the smartctl command with the provided arguments and return the output.
    """
    smartctl_path = os.getenv("SMARTCTL_PATH", "C:\\Program Files\\smartmontools\\bin\\smartctl.exe")
    if not os.path.exists(smartctl_path):
        logger.error(f"smartctl not found at {smartctl_path}")
        raise FileNotFoundError(f"smartctl not found at {smartctl_path}")

    try:
        result = subprocess.run(
            [smartctl_path] + args,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )
        if result.returncode != 0:
            logger.error(f"smartctl command failed: {result.stderr.strip()}")
            raise RuntimeError(f"smartctl error: {result.stderr.strip()}")
        return result.stdout.strip()
    except Exception as e:
        logger.error(f"Failed to run smartctl command: {e}")
        raise RuntimeError(f"Failed to run smartctl: {e}")

def parse_scan_output(scan_output):
    """
    Parse the output of the smartctl --scan command and return a list of disk identifiers.
    """
    disks = []
    for line in scan_output.splitlines():
        if line:
            parts = line.split()
            if parts:
                disks.append(parts[0])
    return disks

def check_disk_health():
    """
    Check the health status of connected disks using smartctl.
    """
    try:
        # Run the --scan command to list all disks
        logger.info("Scanning for connected disks...")
        scan_output = run_smartctl_command(["--scan"])
        logger.debug(f"Raw --scan output: {scan_output}")

        # Parse the disk identifiers
        disks = parse_scan_output(scan_output)

        if not disks:
            logger.warning("No disks found during scan.")
            return "No disks detected."

        health_status = {}
        for disk in disks:
            try:
                logger.info(f"Checking health for disk: {disk}")
                # Check disk health for each detected disk
                health_output = run_smartctl_command(["-H", disk])
                if "PASSED" in health_output:
                    health_status[disk] = "Healthy"
                else:
                    health_status[disk] = "Potential issues detected."
            except RuntimeError as e:
                logger.error(f"Error checking health for disk {disk}: {e}")
                health_status[disk] = f"Error: {e}"

        return health_status
    except Exception as e:
        logger.critical(f"Error during disk health check: {e}")
        return f"Error checking disk health: {e}"

def display_alert(message, level):
    """
    Display alerts or log messages based on the level.
    """
    levels = {
        "INFO": logger.info,
        "WARNING": logger.warning,
        "ERROR": logger.error,
        "CRITICAL": logger.critical
    }
    log_func = levels.get(level.upper(), logger.info)
    log_func(message)
    print(f"[{level}] {message}")

# Test block
if __name__ == "__main__":
    logging.basicConfig(level=logging.DEBUG)  # Set to DEBUG for detailed output
    try:
        health_status = check_disk_health()
        if isinstance(health_status, dict):
            for disk, status in health_status.items():
                print(f"{disk}: {status}")
        else:
            print(health_status)
    except Exception as e:
        logger.critical(f"An unexpected error occurred: {e}")
