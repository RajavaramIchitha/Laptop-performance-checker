SMARTCTL_PATH = "C:\\Program Files\\smartmontools\\bin\\smartctl.exe"
CPU_TEMP_THRESHOLD = 85
