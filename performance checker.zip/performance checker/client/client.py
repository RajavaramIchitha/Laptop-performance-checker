import socket
import json
from metrics.battery import get_battery_info
from metrics.disk import check_disk_health
from metrics.performance import get_system_performance
from metrics.temperature import get_cpu_temperature

SERVER_HOST = "127.0.0.1"  # Change to the server's IP address
SERVER_PORT = 5000

def collect_metrics():
    battery_info = get_battery_info()
    disk_health = check_disk_health()
    cpu_usage, ram_usage = get_system_performance()
    cpu_temp = get_cpu_temperature()

    metrics = {
        "battery": battery_info,
        "disk_health": disk_health,
        "cpu_usage": cpu_usage,
        "ram_usage": ram_usage,
        "cpu_temp": cpu_temp,
    }
    return json.dumps(metrics)

def send_metrics_to_server(metrics):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as client_socket:
        client_socket.connect((SERVER_HOST, SERVER_PORT))
        client_socket.sendall(metrics.encode())

if __name__ == "__main__":
    metrics = collect_metrics()
    print(f"Sending metrics: {metrics}")
    send_metrics_to_server(metrics)
