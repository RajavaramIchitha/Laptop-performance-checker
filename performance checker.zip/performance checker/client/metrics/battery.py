import psutil
import logging

logger = logging.getLogger(__name__)

def get_battery_info():
    try:
        battery = psutil.sensors_battery()
        if battery:
            percentage = battery.percent
            cycles = getattr(battery, 'cycles', 'N/A')  # Check if 'cycles' attribute exists
            if battery.secsleft == psutil.POWER_TIME_UNLIMITED:
                time_left = "Unlimited"
            elif battery.secsleft == psutil.POWER_TIME_UNKNOWN:
                time_left = "Unknown"
            else:
                time_left = round(battery.secsleft / 60, 2)  # Time left in minutes
            return percentage, cycles, time_left
        else:
            logger.warning("No battery detected on the system.")
            return "No battery detected", None, None
    except AttributeError:
        logger.error("Battery information not supported on this system.")
        return "Battery information not supported on this system", None, None
    except Exception as e:
        logger.error(f"Error fetching battery info: {e}")
        return f"Error fetching battery info: {e}", None, None

# Test block
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    percentage, cycles, time_left = get_battery_info()
    print(f"Battery Percentage: {percentage}")
    print(f"Battery Cycles: {cycles}")
    print(f"Battery Time Left: {time_left}")


