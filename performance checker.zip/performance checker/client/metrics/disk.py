import subprocess

def check_disk_health(disk="sda"):
    try:
        # Run smartctl command to get disk health data
        command = f"smartctl -H /dev/{disk}"  # Requires smartmontools installed
        result = subprocess.run(command, shell=True, capture_output=True, text=True)
        if result.returncode == 0:
            # Extract health status
            if "PASSED" in result.stdout:
                return "Healthy"
            else:
                return "Problem Detected"
        return "Unable to get disk health data"
    except Exception as e:
        return f"Error: {e}"

# Test the function when the script is run directly
if __name__ == "__main__":
    disk = "sda"  # Replace with your actual disk identifier
    health_status = check_disk_health(disk)
    print(f"Disk Health for {disk}: {health_status}")


