import psutil
import logging

logger = logging.getLogger(__name__)

def get_system_performance(interval=1):
    """
    Get the current system performance metrics, including CPU and RAM usage.

    Args:
        interval (int): The interval in seconds to calculate the average CPU usage.

    Returns:
        tuple: A tuple containing CPU usage (float) and RAM usage (float) in percentage.
    """
    try:
        logger.info("Fetching system performance metrics...")
        cpu_usage = psutil.cpu_percent(interval=interval)
        ram_usage = psutil.virtual_memory().percent
        logger.debug(f"CPU Usage: {cpu_usage}%, RAM Usage: {ram_usage}%")
        return cpu_usage, ram_usage
    except Exception as e:
        logger.error(f"Error fetching system performance metrics: {e}")
        raise RuntimeError(f"Failed to retrieve performance metrics: {e}")

# Test the function when the script is run directly
if __name__ == "__main__":
    # Configure basic logging
    logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
    
    try:
        cpu_usage, ram_usage = get_system_performance()
        print(f"CPU Usage: {cpu_usage}%")
        print(f"RAM Usage: {ram_usage}%")
    except Exception as e:
        print(f"Error: {e}")


