import unittest
from client.metrics.battery import get_battery_info
from client.metrics.disk import get_disk_usage
from client.metrics.performance import get_system_performance
from client.metrics.temperature import get_cpu_temperature

class TestMetrics(unittest.TestCase):
    def test_battery_info(self):
        result = get_battery_info()
        self.assertIn("percent", result)

    def test_disk_usage(self):
        result = get_disk_usage()
        self.assertIn("total", result)

    def test_system_performance(self):
        result = get_system_performance()
        self.assertIn("cpu", result)

    def test_cpu_temperature(self):
        result = get_cpu_temperature()
        self.assertTrue(result is not None)

if __name__ == '__main__':
    unittest.main()
