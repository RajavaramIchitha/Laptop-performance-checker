document.addEventListener("DOMContentLoaded", () => {
    const timeLeftElement = document.getElementById("time-left"); // Element to display the timer
    const startButton = document.getElementById("start-button"); // Start button for the timer

    let timeLeft = 60; // Initialize the timer with 60 seconds
    let timerInterval; // Variable to store the timer interval

    // Function to update the timer display
    function updateTimeLeft() {
        timeLeftElement.textContent = `Time Left: ${timeLeft} seconds`; // Update the text content
        if (timeLeft === 0) {
            clearInterval(timerInterval); // Stop the timer when it reaches 0
            timeLeftElement.textContent = "Time's up!";
        } else {
            timeLeft--; // Decrement the timer
        }
    }

    // Event listener for the start button
    startButton.addEventListener("click", () => {
        clearInterval(timerInterval); // Clear any existing timer to avoid overlap
        timeLeft = 60; // Reset the timer to 60 seconds
        timerInterval = setInterval(updateTimeLeft, 1000); // Start the timer with an interval of 1 second
    });
});
