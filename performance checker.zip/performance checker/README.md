# Laptop Performance Checker

## Features
- Real-time monitoring of CPU, RAM, disk health, and battery status.
- Visual alerts for threshold breaches.

## Setup
1. Install dependencies:
   ```bash
   pip install -r requirements.txt
